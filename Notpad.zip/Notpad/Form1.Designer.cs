﻿namespace Notpad
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            fILEToolStripMenuItem = new ToolStripMenuItem();
            nEWToolStripMenuItem = new ToolStripMenuItem();
            newWindowToolStrip = new ToolStripMenuItem();
            saveToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem8 = new ToolStripMenuItem();
            openToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem7 = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripMenuItem();
            undoToolStripMenuItem = new ToolStripMenuItem();
            redoToolStripMenuItem = new ToolStripMenuItem();
            cutToolStripMenuItem = new ToolStripMenuItem();
            pasteToolStripMenuItem = new ToolStripMenuItem();
            copyToolStripMenuItem = new ToolStripMenuItem();
            selectAlltoolStripMenuItem4 = new ToolStripMenuItem();
            timeDateToolsStrip = new ToolStripMenuItem();
            selectAllToolStripMenuItem = new ToolStripMenuItem();
            familyToolStripMenuItem1 = new ToolStripMenuItem();
            styleToolStripMenuItem1 = new ToolStripMenuItem();
            colorToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem2 = new ToolStripMenuItem();
            fontToolStripMenuItem = new ToolStripMenuItem();
            zoomInToolStripMenuItem = new ToolStripMenuItem();
            zoomOutToolStripMenuItem = new ToolStripMenuItem();
            StatusbartoolStripMenuItem = new ToolStripMenuItem();
            wordWraptoolStripMenuItem10 = new ToolStripMenuItem();
            defaulzoomttoolStripMenuItem = new ToolStripMenuItem();
            richTextBox1 = new RichTextBox();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { fILEToolStripMenuItem, toolStripMenuItem1, toolStripMenuItem2 });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(12, 4, 0, 4);
            menuStrip1.Size = new Size(793, 40);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fILEToolStripMenuItem
            // 
            fILEToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { nEWToolStripMenuItem, newWindowToolStrip, saveToolStripMenuItem, toolStripMenuItem8, openToolStripMenuItem, toolStripMenuItem7, exitToolStripMenuItem });
            fILEToolStripMenuItem.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            fILEToolStripMenuItem.ForeColor = SystemColors.InactiveCaptionText;
            fILEToolStripMenuItem.Name = "fILEToolStripMenuItem";
            fILEToolStripMenuItem.Size = new Size(59, 32);
            fILEToolStripMenuItem.Text = "File";
            // 
            // nEWToolStripMenuItem
            // 
            nEWToolStripMenuItem.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nEWToolStripMenuItem.Name = "nEWToolStripMenuItem";
            nEWToolStripMenuItem.Size = new Size(300, 32);
            nEWToolStripMenuItem.Text = "NEW                                ";
            nEWToolStripMenuItem.Click += nEWToolStripMenuItem_Click;
            // 
            // newWindowToolStrip
            // 
            newWindowToolStrip.Name = "newWindowToolStrip";
            newWindowToolStrip.Size = new Size(300, 32);
            newWindowToolStrip.Text = "New Window";
            newWindowToolStrip.Click += toolStripMenuItem6_Click;
            // 
            // saveToolStripMenuItem
            // 
            saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            saveToolStripMenuItem.Size = new Size(300, 32);
            saveToolStripMenuItem.Text = "Save";
            saveToolStripMenuItem.Click += saveToolStripMenuItem_Click;
            // 
            // toolStripMenuItem8
            // 
            toolStripMenuItem8.Name = "toolStripMenuItem8";
            toolStripMenuItem8.Size = new Size(300, 32);
            toolStripMenuItem8.Text = "Save as";
            toolStripMenuItem8.Click += toolStripMenuItem8_Click;
            // 
            // openToolStripMenuItem
            // 
            openToolStripMenuItem.Name = "openToolStripMenuItem";
            openToolStripMenuItem.Size = new Size(300, 32);
            openToolStripMenuItem.Text = "Open";
            openToolStripMenuItem.Click += openToolStripMenuItem_Click;
            // 
            // toolStripMenuItem7
            // 
            toolStripMenuItem7.Name = "toolStripMenuItem7";
            toolStripMenuItem7.Size = new Size(300, 32);
            toolStripMenuItem7.Text = "Print";
            toolStripMenuItem7.Click += toolStripMenuItem7_Click_1;
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(300, 32);
            exitToolStripMenuItem.Text = "Exit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[] { undoToolStripMenuItem, redoToolStripMenuItem, cutToolStripMenuItem, pasteToolStripMenuItem, copyToolStripMenuItem, selectAlltoolStripMenuItem4, timeDateToolsStrip, selectAllToolStripMenuItem });
            toolStripMenuItem1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(63, 32);
            toolStripMenuItem1.Text = "Edit";
            toolStripMenuItem1.Click += toolStripMenuItem1_Click;
            // 
            // undoToolStripMenuItem
            // 
            undoToolStripMenuItem.Name = "undoToolStripMenuItem";
            undoToolStripMenuItem.Size = new Size(224, 32);
            undoToolStripMenuItem.Text = "Undo";
            undoToolStripMenuItem.Click += undoToolStripMenuItem_Click;
            // 
            // redoToolStripMenuItem
            // 
            redoToolStripMenuItem.Name = "redoToolStripMenuItem";
            redoToolStripMenuItem.Size = new Size(224, 32);
            redoToolStripMenuItem.Text = "Redo";
            redoToolStripMenuItem.Click += redoToolStripMenuItem_Click;
            // 
            // cutToolStripMenuItem
            // 
            cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            cutToolStripMenuItem.Size = new Size(224, 32);
            cutToolStripMenuItem.Text = "Cut";
            cutToolStripMenuItem.Click += cutToolStripMenuItem_Click;
            // 
            // pasteToolStripMenuItem
            // 
            pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            pasteToolStripMenuItem.Size = new Size(224, 32);
            pasteToolStripMenuItem.Text = "Paste";
            pasteToolStripMenuItem.Click += pasteToolStripMenuItem_Click;
            // 
            // copyToolStripMenuItem
            // 
            copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            copyToolStripMenuItem.Size = new Size(224, 32);
            copyToolStripMenuItem.Text = "Copy";
            copyToolStripMenuItem.Click += copyToolStripMenuItem_Click;
            // 
            // selectAlltoolStripMenuItem4
            // 
            selectAlltoolStripMenuItem4.Name = "selectAlltoolStripMenuItem4";
            selectAlltoolStripMenuItem4.Size = new Size(224, 32);
            selectAlltoolStripMenuItem4.Text = "Select All";
            selectAlltoolStripMenuItem4.Click += toolStripMenuItem4_Click;
            // 
            // timeDateToolsStrip
            // 
            timeDateToolsStrip.Name = "timeDateToolsStrip";
            timeDateToolsStrip.Size = new Size(224, 32);
            timeDateToolsStrip.Text = "Time/Date";
            // 
            // selectAllToolStripMenuItem
            // 
            selectAllToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { familyToolStripMenuItem1, styleToolStripMenuItem1, colorToolStripMenuItem });
            selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            selectAllToolStripMenuItem.Size = new Size(224, 32);
            selectAllToolStripMenuItem.Text = "Font";
            selectAllToolStripMenuItem.Click += selectAllToolStripMenuItem_Click;
            // 
            // familyToolStripMenuItem1
            // 
            familyToolStripMenuItem1.Name = "familyToolStripMenuItem1";
            familyToolStripMenuItem1.Size = new Size(224, 32);
            familyToolStripMenuItem1.Text = "Family";
            familyToolStripMenuItem1.Click += familyToolStripMenuItem1_Click;
            // 
            // styleToolStripMenuItem1
            // 
            styleToolStripMenuItem1.Name = "styleToolStripMenuItem1";
            styleToolStripMenuItem1.Size = new Size(224, 32);
            styleToolStripMenuItem1.Text = "Style";
            styleToolStripMenuItem1.Click += styleToolStripMenuItem1_Click;
            // 
            // colorToolStripMenuItem
            // 
            colorToolStripMenuItem.Name = "colorToolStripMenuItem";
            colorToolStripMenuItem.Size = new Size(224, 32);
            colorToolStripMenuItem.Text = "Color";
            colorToolStripMenuItem.Click += colorToolStripMenuItem_Click_1;
            // 
            // toolStripMenuItem2
            // 
            toolStripMenuItem2.DropDownItems.AddRange(new ToolStripItem[] { fontToolStripMenuItem, StatusbartoolStripMenuItem, wordWraptoolStripMenuItem10, defaulzoomttoolStripMenuItem });
            toolStripMenuItem2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            toolStripMenuItem2.Name = "toolStripMenuItem2";
            toolStripMenuItem2.Size = new Size(72, 32);
            toolStripMenuItem2.Text = "View";
            // 
            // fontToolStripMenuItem
            // 
            fontToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { zoomInToolStripMenuItem, zoomOutToolStripMenuItem });
            fontToolStripMenuItem.Name = "fontToolStripMenuItem";
            fontToolStripMenuItem.Size = new Size(227, 32);
            fontToolStripMenuItem.Text = "Zoom";
            fontToolStripMenuItem.Click += fontToolStripMenuItem_Click;
            // 
            // zoomInToolStripMenuItem
            // 
            zoomInToolStripMenuItem.Name = "zoomInToolStripMenuItem";
            zoomInToolStripMenuItem.Size = new Size(190, 32);
            zoomInToolStripMenuItem.Text = "Zoom in";
            zoomInToolStripMenuItem.Click += zoomInToolStripMenuItem_Click;
            // 
            // zoomOutToolStripMenuItem
            // 
            zoomOutToolStripMenuItem.Name = "zoomOutToolStripMenuItem";
            zoomOutToolStripMenuItem.Size = new Size(190, 32);
            zoomOutToolStripMenuItem.Text = "Zoom out";
            zoomOutToolStripMenuItem.Click += zoomOutToolStripMenuItem_Click;
            // 
            // StatusbartoolStripMenuItem
            // 
            StatusbartoolStripMenuItem.Name = "StatusbartoolStripMenuItem";
            StatusbartoolStripMenuItem.Size = new Size(227, 32);
            StatusbartoolStripMenuItem.Text = "Status bar";
            StatusbartoolStripMenuItem.Click += StatusbartoolStripMenuItem_Click;
            // 
            // wordWraptoolStripMenuItem10
            // 
            wordWraptoolStripMenuItem10.Name = "wordWraptoolStripMenuItem10";
            wordWraptoolStripMenuItem10.Size = new Size(227, 32);
            wordWraptoolStripMenuItem10.Text = "Word wrap";
            wordWraptoolStripMenuItem10.Click += wordWraptoolStripMenuItem10_Click;
            // 
            // defaulzoomttoolStripMenuItem
            // 
            defaulzoomttoolStripMenuItem.Name = "defaulzoomttoolStripMenuItem";
            defaulzoomttoolStripMenuItem.Size = new Size(227, 32);
            defaulzoomttoolStripMenuItem.Text = "Default zoom";
            defaulzoomttoolStripMenuItem.Click += defaulzoomttoolStripMenuItem_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.BorderStyle = BorderStyle.None;
            richTextBox1.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            richTextBox1.Location = new Point(8, 43);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(773, 350);
            richTextBox1.TabIndex = 1;
            richTextBox1.Text = "";
            richTextBox1.TextChanged += richTextBox1_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(16F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(793, 435);
            Controls.Add(richTextBox1);
            Controls.Add(menuStrip1);
            Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(6);
            Name = "Form1";
            Text = "Notpad";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fILEToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem2;
        private ToolStripMenuItem nEWToolStripMenuItem;
        private ToolStripMenuItem saveToolStripMenuItem;
        private ToolStripMenuItem openToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem undoToolStripMenuItem;
        private ToolStripMenuItem redoToolStripMenuItem;
        private ToolStripMenuItem cutToolStripMenuItem;
        private ToolStripMenuItem pasteToolStripMenuItem;
        private ToolStripMenuItem copyToolStripMenuItem;
        private ToolStripMenuItem selectAllToolStripMenuItem;
        private ToolStripMenuItem fontToolStripMenuItem;
        private RichTextBox richTextBox1;
        private ToolStripMenuItem defaulzoomttoolStripMenuItem;
        private ToolStripMenuItem newWindowToolStrip;
        private ToolStripMenuItem selectAlltoolStripMenuItem4;
        private ToolStripMenuItem timeDateToolsStrip;
        private ToolStripMenuItem toolStripMenuItem8;
        private ToolStripMenuItem toolStripMenuItem7;
        private ToolStripMenuItem zoomInToolStripMenuItem;
        private ToolStripMenuItem zoomOutToolStripMenuItem;
        private ToolStripMenuItem StatusbartoolStripMenuItem;
        private ToolStripMenuItem wordWraptoolStripMenuItem10;
        private ToolStripMenuItem familyToolStripMenuItem1;
        private ToolStripMenuItem styleToolStripMenuItem1;
        private ToolStripMenuItem colorToolStripMenuItem;
    }
}
