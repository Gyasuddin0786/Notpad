using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Drawing.Printing;

namespace Notpad
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog o = new OpenFileDialog();
            o.Title = "OPen a Text FIle";
            o.Filter = "*.* | *.txt ";
            DialogResult dr = o.ShowDialog();
            if (dr == DialogResult.OK)
            {
                TextReader tr = new StreamReader(o.FileName);
                richTextBox1.Text = tr.ReadToEnd();
                tr.Close();
            }
        }

        private void nEWToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text != "")
            {
                DialogResult dr = MessageBox.Show("Do you want to save ?", "Confirmation ", MessageBoxButtons.OKCancel);
                if (dr == DialogResult.OK)
                {
                    SaveFileDialog sf = new SaveFileDialog();
                    sf.Title = "Save a Text FIle";
                    sf.Filter = "*.txt | *.*";
                    DialogResult drr = sf.ShowDialog();
                    if (drr == DialogResult.OK)
                    {
                        TextWriter tr = new StreamWriter(sf.FileName);
                        tr.Write(richTextBox1.Text);
                        tr.Close();
                    }
                    else if (dr == DialogResult.Cancel) {
                        TextWriter tr = new StreamWriter(sf.FileName);
                        tr.Write(richTextBox1.Text);
                        tr.Close();
                    }
                    richTextBox1.Text = "";
                }
            }

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sf = new SaveFileDialog();
            sf.Title = "Save a Text FIle";
            sf.Filter = "*.txt | *.*";
            DialogResult dr = sf.ShowDialog();
            if (dr == DialogResult.OK)
            {
                TextWriter tr = new StreamWriter(sf.FileName);
                tr.Write(richTextBox1.Text);
                tr.Close();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to exit ?",
            "Confirmation ", MessageBoxButtons.OKCancel);
            if (dr == DialogResult.OK)
            {
                this.Close();
            }
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Redo();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(richTextBox1.SelectedText);
            richTextBox1.SelectedText = "";
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(richTextBox1.SelectedText);
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str = Clipboard.GetText();
            richTextBox1.Text = richTextBox1.Text.Insert(richTextBox1.SelectionStart, str);
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectAll();
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)

        {
            FontDialog fontDialog = new FontDialog();
            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.Font = fontDialog.Font;
            }
        }

        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.ForeColor = colorDialog.Color;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Application.Exit();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            Form1 newForm = new Form1();
            newForm.Show();
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            SaveFileDialog sf = new SaveFileDialog();
            sf.Title = "Save As Text File";
            sf.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            DialogResult dr = sf.ShowDialog();
            if (dr == DialogResult.OK)
            {
                TextWriter tr = new StreamWriter(sf.FileName);
                tr.Write(richTextBox1.Text);
                tr.Close();
            }
        }

        private void toolStripMenuItem7_Click_1(object sender, EventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            PrintDocument printDocument = new PrintDocument();

            printDialog.Document = printDocument;
            printDocument.PrintPage += new PrintPageEventHandler(PrintDocument_PrintPage);

            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                printDocument.Print();
            }

        }
        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            e.Graphics.DrawString(richTextBox1.Text, richTextBox1.Font, Brushes.Black, new PointF(100, 100));
        }

        private void zoomInToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.ZoomFactor += 0.1f;
        }

        private void zoomOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.ZoomFactor -= 0.1f;
        }

        private void StatusbartoolStripMenuItem_Click(object sender, EventArgs e)
        {
            //  richTextBox1.Statusbar = richTextBox1.Statusbar;
        }

        private void wordWraptoolStripMenuItem10_Click(object sender, EventArgs e)
        {
            richTextBox1.WordWrap = !richTextBox1.WordWrap;
        }

        private void defaulzoomttoolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.ZoomFactor = 1.0f;
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            //select all text
        }

        private void familyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //font faimly

        }

        private void styleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //style

        }

        private void familyToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                Font newFont = new Font(fontDialog.Font.FontFamily, richTextBox1.Font.Size);
                richTextBox1.Font = newFont;
            }
        }

        private void styleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                FontStyle style = FontStyle.Regular;
                if (fontDialog.Font.Bold)
                    style |= FontStyle.Bold;
                if (fontDialog.Font.Italic)
                    style |= FontStyle.Italic;

                Font newFont = new Font(richTextBox1.Font.FontFamily, richTextBox1.Font.Size, style);
                richTextBox1.Font = newFont;
            }
        }

        private void colorToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                // Change the color of the selected text
                richTextBox1.SelectionColor = colorDialog.Color;
            }
        }
    }
}
